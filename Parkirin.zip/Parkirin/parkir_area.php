                            <?php include 'koneksi.php';

                              $sensor = mysqli_query($koneksi, "SELECT * from tbl_area");
                              foreach ($sensor as $row) {
                              }
                            ?>                     

                          <div class="text-center">
                            <table align="center" style=" border-style: solid; border-bottom-style: hidden; border-color:black; border-spacing:1">
                              <tr>
                                  <td bgcolor="black">-</td>
                                <td>
                                  <button class="btn btn-danger btn-lg disabled"> C01 </button>
                                </td>
                                <td bgcolor="black">--</td>
                                <td>
                                    <?php if ($row['ping1'] >= "5") { ?>
                                        <button class="btn btn-default btn-lg disabled" value="<?php echo $row["ping1"]?>"> C02 </button>
                                    <?php } ?>

                                    <?php if ($row['ping1'] < "5") { ?>
                                        <button class="btn btn-danger btn-lg disabled" value="<?php echo $row["ping1"]?>"> C02 </button>
                                    <?php } ?>
                                </td>
                                <td bgcolor="black">--</td>
                                <td>
                                    <button class="btn btn-danger btn-lg disabled"> C03 </button>
                                </td>
                                <td bgcolor="black">--</td>
                                <td>
                                    <?php if ($row['ping2'] >= "5") { ?>
                                        <button class="btn btn-default btn-lg disabled" value="<?php echo $row["ping2"]?>"> C04 </button>
                                    <?php } ?>

                                    <?php if ($row['ping2'] < "5") { ?>
                                        <button class="btn btn-danger btn-lg disabled" value="<?php echo $row["ping2"]?>"> C04 </button>
                                    <?php } ?>
                                </td>
                                <td bgcolor="black">--</td>
                                <td>
                                    <?php if ($row['ping3'] >= "5") { ?>
                                        <button class="btn btn-default btn-lg disabled" value="<?php echo $row["ping3"]?>"> C05 </button>
                                    <?php } ?>

                                    <?php if ($row['ping3'] < "5") { ?>
                                        <button class="btn btn-danger btn-lg disabled" value="<?php echo $row["ping3"]?>"> C05 </button>
                                    <?php } ?>
                                </td>
                                <td bgcolor="black">-</td>
                              </tr>
                            </table>
                            </div>

                            <table align="right" style=" border-style: solid; border-left-style: hidden; border-color:black; ">
                              <?php
                                  $query = "SELECT * FROM tbl_slot";
                                  $result = mysqli_query($koneksi, $query);
                                  foreach($result as $parkiran) :
                                      if ($parkiran['posisi'] == "KIRI") {
                              ?>
                              <tr>  
                              <td>
                                <?php if ($parkiran['status'] == "DIPESAN") { ?>
                                  <button class="btn btn-danger btn-lg disabled" value="<?php echo $parkiran['id_slot']; ?>">
                                  <?php echo $parkiran["nomor_slot"] ?>
                                  </button>
                                <?php } ?>

                                <?php if ($parkiran['status'] == "KOSONG") { ?>
                                  <a href="edit.php?id_slot=<?php echo $parkiran['id_slot']; ?>">
                                  <button class="btn btn-default btn-lg"><?php echo $parkiran['nomor_slot']; ?>
                                  </button></a>
                                <?php } ?>
                              </td>
                              <tr><td bgcolor="black">----------</td></tr>
                              <?php } endforeach ?>
                            </table>



                            <table align="left" style=" border-style: solid; border-right-style: hidden; border-color:black;">
                            <?php
                                  $query = "SELECT * FROM tbl_slot";
                                  $result = mysqli_query($koneksi, $query);
                                  foreach($result as $parkiran) :
                                      if ($parkiran['posisi'] == "KANAN") {
                              ?>
                              <tr>  
                              <td>
                                <?php if ($parkiran['status'] == "DIPESAN") { ?>
                                  <button class="btn btn-danger btn-lg disabled" value="<?php echo $parkiran['id_slot']; ?>">
                                  <?php echo $parkiran["nomor_slot"] ?>
                                  </button>
                                <?php } ?>

                                <?php if ($parkiran['status'] == "KOSONG") { ?>
                                  <a href="edit.php?id_slot=<?php echo $parkiran['id_slot']; ?>">
                                  <button class="btn btn-default btn-lg"><?php echo $parkiran['nomor_slot']; ?>
                                  </button></a>
                                <?php } ?>
                              </td>
                              <tr><td bgcolor="black">----------</td></tr>
                              </tr>
                              <?php } endforeach ?>
                            </table>
            