<div class="text-center">
    <table class="table table-hover table-striped tablesorter">
      <tr>
        <td></td>
        <td>
        <button type="button" class="btn btn-default btn-lg disabled">Kosong</button>
      </td>
      <td>
        <button type="button" class="btn btn-danger btn-lg disabled">Terisi</button>
      </td>
      <td></td>
      </tr>
    </table>
  </div>
</div>