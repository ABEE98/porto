                          <?php
          									include 'koneksi.php';
                            $id_slot = $_GET['id_slot'];
          									$data = mysqli_query($koneksi,"select * from tbl_slot where id_slot='$id_slot'");
          									while($d = mysqli_fetch_array($data)){
          								?>
										
                              <form method="post" action="cetak.php">
          											
          											<div class="form-group">
          											<label for="disabledSelect">Nomor Slot</label>
          											<input type="hidden" name="id_slot" value="<?php echo $d['id_slot']; ?>">
          											<input class="form-control" type="text" name="nomor_slot" value="<?php echo $d['nomor_slot']; ?>" readonly>
          											</div>
          													
          											<div class="form-group">
          											<label for="disabledSelect">Status Slot</label>
          											<input class="form-control" type="text" name="status" value="DIPESAN" readonly>
          											</div>        													

                                <input type="hidden" class="form-control" type="text" name="kode_res"
                                 value="<?php echo $kode_res = uniqid();?>">

                                <div class="form-group">
                                  <label>Nama</label>
                                  <input class="form-control" type="text" name="nama">
                                  <p class="help-block">example: JOJO</p>
                                </div>

                                <div class="form-group">
                                  <label>Nomor Kendaraan (Plat Nomor)</label>
                                  <input class="form-control" type="text" name="tnkb">
                                  <p class="help-block">example: E1111XX</p>
                                </div>

                                <div class="form-group">
                                  <label>No Telp</label>
                                  <input class="form-control" type="text" name="kontak">
                                  <p class="help-block">example: 6280000000000</p>
                                </div>

                                <div class="form-group">
                                  <button class="btn btn-primary" type="submit" name="Reservasi" >SIMPAN
                                  </button>
                                </div>

                            </form>

                          <?php 
                            }
                          ?>
