<?php
	include ("koneksi.php");
	$ping1 = $_GET['ping1'];
	$ping2 = $_GET['ping2'];
	$ping3 = $_GET['ping3'];

	$query="INSERT INTO tbl_area SET ping1='$ping1',ping2='$ping2',ping3='$ping3' ";
	mysqli_query($koneksi,$query);
?>