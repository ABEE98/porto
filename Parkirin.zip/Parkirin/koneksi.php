<?php 
$koneksi = mysqli_connect("localhost","id11055033_azis","14515648","id11055033_dbsensor");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>