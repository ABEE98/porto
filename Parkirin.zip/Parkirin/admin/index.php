<?php
session_start();
include "head.php";

if (empty($_SESSION['username'])){
  
	header('location:../login.php');
}
else
{
?>
<div id="page-wrapper">
        <div class="row">
          <div class="col-lg-15">
            <div class="panel panel-default">
              <div class="panel-body">
                <div id="morris-chart-area">
                  <div class="row">
                    
                    <!-- Keterangan -->
                    <div class="col-lg-5">
                      <div class="panel panel-info">
                        <div class="panel-heading">
                          <h3 class="panel-title"><center> Data Slot</center></h3>
                        </div>
                        <div class="panel-body"> 
                          <div class="list-group">  

                              <div class="table-responsive">
                                <table class="table table-hover table-striped tablesorter">
                                  <tr> 
                                      <th>NO</th>
                                      <th>NOMOR SLOT</i></th>
                                      <th>STATUS</th>
                                      <th>POSISI</th>
                                  </tr>
                                    <?php
                                        include "../koneksi.php";
                                        $result = mysqli_query($koneksi, "SELECT * FROM tbl_slot");
                                        while($row = mysqli_fetch_assoc($result)) { 
                                    ?>
                                  <tr>  
                                      <td><?php echo $row['id_slot'];?></td>
                                      <td><?php echo $row['nomor_slot']; ?></td>
                                      <td><?php echo $row['status'];?></td>
                                      <td><?php echo $row['posisi'];?></td>
                                      
                                  </tr>
                                  <?php } ?>
                                </table>
                              </div>

                          </div>
                        </div>
                      </div>
                    </div>


                    <!-- Area -->
                    <div class="col-lg-7">
                      <div class="panel panel-info">
                        <div class="panel-heading">
                          <h3 class="panel-title"><center>Data Reservasi</center></h3>
                        </div>
                        <div class="panel-body">
                          <div class="list-group">
                            
                              <div class="table-responsive">
                                <table class="table table-hover table-striped tablesorter">
                                  <tr align="center"> 
                                      <th>Kode Reservasi</i></th>
                                      <th>Nomor Slot</th>
                                      <th>TNKB</th>
                                      <th>Nama</th>
                                      <th>Kontak</th>
                                  </tr>
                                    <?php
                                        include "../koneksi.php";
                                        $result = mysqli_query($koneksi, "SELECT * FROM reserveasi");
                                        while($row = mysqli_fetch_assoc($result)) {
                                    ?>
                                  <tr>
                                      <td><?php echo $row['kode_res'];?></td>
                                      <td><?php echo $row['nomor_slot']; ?></td>
                                      <td><?php echo $row['tnkb'];?></td>
                                      <td><?php echo $row['nama'];?></td>
                                      <td><?php echo $row['kontak'];?></td>
                                  </tr>
                                  <?php } ?>
                                </table>
                              </div>

                          </div>
                        </div>
                      </div>
                    </div>

                </div>
              </div>
            </div>
          </div>
        </div>

<?php 
} include 'foot.php' 
?>