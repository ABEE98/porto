<?php
include "head.php";
session_start();
if (empty($_SESSION['username'])){
header('location:../login.php');
}
else
{
?>
      <div id="page-wrapper">
        <div class="row"> 
          <div class="col-lg-14">
            <div class="panel panel-info">
              <div class="panel-body">
                <div class="list-group">  
                    <center><h2>SLOT PARKIR</h2></center>
                      <div class="table-responsive">
                        <table class="table table-hover table-striped tablesorter">
                          <tr> 
                              <th>NO</th>
                              <th>NOMOR SLOT</i></th>
                              <th>STATUS</th>
                              <th>POSISI</th>
                              <th>AKSI</th>
                          </tr>
                            <?php
                                include "../koneksi.php";
                                $result = mysqli_query($koneksi, "SELECT * FROM tbl_slot");
                                while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                          <tr>  
                              <td><?php echo $row['id_slot'];?></td>
                              <td><?php echo $row['nomor_slot']; ?></td>
                              <td><?php echo $row['status'];?></td>
                              <td><?php echo $row['posisi'];?></td>
                              <td>
                                  <a href="edit_slot.php?id_slot=<?php echo $row['id_slot']; ?>">
                                  <button class="btn btn-warning fa fa-edit">
                                  </button></a>
                              </td>
                          </tr>
                          <?php
                          }
                          ?>
                        </table>
                      </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<!-- /.row -->
<?php
}
include "foot.php";?>