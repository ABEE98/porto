<?php

include "../koneksi.php";

if(isset($_GET['kode_res'])){
    $kode_res = $_GET['kode_res'];

    $sql = "DELETE FROM reserveasi WHERE kode_res='$kode_res'";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
    	header('location: data_reservasi.php');
    }else{
    	die("gagal hapus");
    }
} else {
	die("akses diblokir");
}

?>