<?php 
 include "head.php";

  session_start();

  if (empty($_SESSION['username'])){
    
    header('location:../login.php');
  }
  else
  {

 ?>
    <div align="center">
      <div id="page-wrapper" align="center">
        <div class="row">
          <div class="col-lg-6">
            <div class="panel panel-info">
              <div class="panel-heading">
                <h3 class="panel-title">Selesaikan Transaksi</h3>
              </div>
              <div class="panel-body" align="center">
                  <div class="text-left">
                      <?php
                        include "../koneksi.php";
                        $kode_res = $_GET['kode_res'];
                        $data = mysqli_query($koneksi,"select * from reserveasi where kode_res='$kode_res'");
                        while($d = mysqli_fetch_array($data)){
                      ?>             
                    <form method="post" action="aksi.php">       
                      <div class="form-group">
                      <label for="disabledSelect">Kode Reservasi</label>
                      <input class="form-control" type="text" name="kode_res" value="<?php echo $d['kode_res']; ?>" readonly>                 
                      </div>
                      <input type="hidden" name="id_slot" value="<?php echo $d['id_slot']; ?>" readonly>
                      
                      <div class="form-group">
                      <label for="disabledSelect">Nomor Slot</label>
                      <input class="form-control" type="text" name="nomor_slot" value="<?php echo $d['nomor_slot']; ?>" readonly>
                      </div>
                      <div class="form-group">
                      <label for="disabledSelect">Status Slot</label>
                      <input class="form-control" type="text" name="status" value="KOSONG" readonly>
                      </div> 
                      <div class="form-group">
                      <label for="disabledSelect">Nama</label>
                      <input class="form-control" type="text" name="nama" value="<?php echo $d['nama']; ?>" readonly>
                      </div> 
                      <div class="form-group">
                      <label for="disabledSelect">Nomor Kendaraan</label>
                      <input class="form-control" type="text" name="tnkb" value="<?php echo $d['tnkb']; ?>" readonly>
                      </div> 
                      <div class="form-group">
                      <label for="disabledSelect">Nomor Kontak</label>
                      <input class="form-control" type="text" name="kontak" value="<?php echo $d['kontak']; ?>" readonly>
                      </div> 
                      <div class="form-group">
                        <button class="btn btn-primary" type="submit" name="Edit_res" >Selesaikan
                        </button>
                      </div>
                      <?php } ?>   
                    </form>                              
      						  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php 
 }
 include "foot.php";
?>