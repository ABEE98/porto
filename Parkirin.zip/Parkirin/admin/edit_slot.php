<?php 
 include "head.php";

 session_start();

  if (empty($_SESSION['username'])){
    
    header('location:../login.php');
  }
  else
  {
 ?>
    <div align="center">
      <div id="page-wrapper" align="center">
        <div class="row">
          <div class="col-lg-6">
            <div class="panel panel-info">
              <div class="panel-heading">
                <h3 class="panel-title">Data Slot</h3>
              </div>
              <div class="panel-body" align="center">
                  <div class="text-left">
                      <?php
                        include "../koneksi.php";
                        $id_slot = $_GET['id_slot'];
                        $data = mysqli_query($koneksi,"select * from tbl_slot where id_slot='$id_slot'");
                        while($d = mysqli_fetch_array($data)){
                      ?>             
                    <form method="post" action="aksi.php">                        
                      <div class="form-group">
                      <label for="disabledSelect">Nomor Slot</label>
                      <input type="hidden" name="id_slot" value="<?php echo $d['id_slot']; ?>">
                      <input class="form-control" type="text" name="nomor_slot" value="<?php echo $d['nomor_slot']; ?>">
                      </div>
                      <div class="form-group">
                      <label for="disabledSelect">Posisi Slot</label>
                      <input class="form-control" type="text" name="posisi" value="<?php echo $d['posisi']; ?>">
                      </div>
                      <div class="form-group">
                      <label for="disabledSelect">Status Slot</label>
                      <input class="form-control" type="text" name="status" value="DIPESAN" readonly>
                      </div> 
                      <div class="form-group">
                        <button class="btn btn-primary" type="submit" name="Edit_slot" >SIMPAN
                        </button>
                      </div>
                      <?php } ?>   
                    </form>                              
      						  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php 
  }
 include "foot.php";
?>