 <?php 

	include "../koneksi.php";

  	  if (isset($_POST['Edit_slot'])) {
      	$id_slot = $_POST['id_slot'];
      	$nomor_slot = $_POST['nomor_slot'];
      	$posisi = $_POST['posisi'];
      	$status = $_POST['status'];

      	mysqli_query($koneksi,"update tbl_slot set nomor_slot='$nomor_slot', posisi='$posisi', status='$status' where id_slot='$id_slot'");

        header("location:data_slot.php");
  	  } 


        elseif (isset($_POST['Edit_res'])) {
        $kode_res = $_POST['kode_res'];
        $id_slot = $_POST['id_slot'];
        $nomor_slot = $_POST['nomor_slot'];
        $status = $_POST['status'];
        $nama = $_POST['nama'];
        $tnkb = $_POST['tnkb'];
        $kontak = $_POST['kontak'];

        mysqli_query($koneksi,"update RESERVEASI set id_slot='id_slot',nomor_slot='$nomor_slot', nama='$nama', tnkb='$tnkb', kontak='$kontak' where kode_res='$kode_res'");

        mysqli_query($koneksi,"update tbl_slot set status='$status' where id_slot='$id_slot'");

        header("location:data_reservasi.php");
      }

  	  //header("location:index.php");

?>