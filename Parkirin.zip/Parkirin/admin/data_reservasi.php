<?php
include "head.php";
session_start();
if (empty($_SESSION['username'])){
header('location:../login.php');
}
else
{
?>
      <div id="page-wrapper">
        <div class="row"> 
          <div class="col-lg-14">
            <div class="panel panel-info">
              <div class="panel-body">
               <center><h2>RESERVASI PARKIR</h2></center>   
                    <form method="post">
                        <input type="text" name="tnkb" placeholder="Cari TNKB">
                        <button class="btn btn-primary fa fa-search" type="submit" name="cari" >
                        </button>
                    </form><br>
                      <div class="table-responsive">
                        <table class="table table-hover table-striped tablesorter">
                          <tr align="center"> 
                              <th>Kode Reservasi</i></th>
                              <th>Nomor Slot</th>
                              <th>TNKB</th>
                              <th>Nama</th>
                              <th>Kontak</th>
                              <th>Aksi</th>
                          </tr>
                            <?php
                              include "../koneksi.php";
                                if (!isset($_POST['cari'])) {
                                  $sql = "SELECT * FROM reserveasi";
                                  $query = mysqli_query($koneksi, $sql);
                                  while($row = mysqli_fetch_assoc($query)) {
                            ?>
                          <tr>
                              <td><?php echo $row['kode_res'];?></td>
                              <td><?php echo $row['nomor_slot']; ?></td>
                              <td><?php echo $row['tnkb'];?></td>
                              <td><?php echo $row['nama'];?></td>
                              <td><?php echo $row['kontak'];?></td>
                              <td>  
                                  <a href="edit_res.php?kode_res=<?php echo $row['kode_res']; ?>">
                                  <button class="btn btn-warning fa fa-edit">
                                  </button></a>  
                                  <a href="hapus.php?kode_res=<?php echo $row['kode_res']; ?>"><button class="btn btn-danger fa fa-trash-o"></button></a>
                              </td>
                          </tr>
                          <?php
                          }
                          }
                          ?>
                          <?php
                              include "../koneksi.php";
                                if (isset($_POST['cari'])) {
                                  $cari = $_POST['tnkb'];
                                  $sql = "SELECT * FROM reserveasi WHERE tnkb LIKE '%$cari%'";
                                  $query = mysqli_query($koneksi, $sql);
                                  while($row = mysqli_fetch_assoc($query)) {
                            ?>
                          <tr>
                              <td><?php echo $row['kode_res'];?></td>
                              <td><?php echo $row['nomor_slot']; ?></td>
                              <td><?php echo $row['tnkb'];?></td>
                              <td><?php echo $row['nama'];?></td>
                              <td><?php echo $row['kontak'];?></td>
                              <td>  
                                  <a href="edit_res.php?kode_res=<?php echo $row['kode_res']; ?>">
                                  <button class="btn btn-warning fa fa-edit">
                                  </button></a>  
                                  <a href="hapus.php?kode_res=<?php echo $row['kode_res']; ?>"><button class="btn btn-danger fa fa-trash-o"></button></a>
                              </td>
                          </tr>
                          <?php
                          }
                          }
                          ?>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          

<!-- /.row -->
<?php
}
include "foot.php";?>