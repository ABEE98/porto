<?php 
 include ("head.php");
 ?>
<div align="center">
      <div id="page-wrapper" align="center">
        <div class="row">
          <div class="col-lg-12">
            <div class="alert alert-success alert-dismissable">
            Lengkapi Form informasi dibawah ini untuk mendapatkan Kode Reservasi
            </div>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Form Reservasi</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <div class="row">
                    <!-- Info -->
                    <div class="col-lg-3">
                      <div class="panel">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="panel panel-info">
                        <div class="panel-heading">
                          <h3 class="panel-title">Data Reservasi</h3>
                        </div>
                        <div class="panel-body" align="center">
                          <div class="text-left">
          								<?php include ("reserve.php"); ?>
          						  </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="panel">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <!-- /.row -->
<?php 
 include ("foot.php");
?>