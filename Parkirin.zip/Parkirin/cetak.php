<?php 
  
  include_once 'koneksi.php';
  
  include "phpqrcode/qrlib.php";
  
  $tempdir = "temp/"; 
    if (!file_exists($tempdir))
        mkdir($tempdir);

  if (isset($_POST['Reservasi'])) {
  //insert data to reservasi
      $kode_res = $_POST ['kode_res'];
      $id_slot = $_POST['id_slot'];
      $nomor_slot = $_POST['nomor_slot'];
      $nama = $_POST['nama'];
      $tnkb = $_POST['tnkb'];
      $kontak = $_POST['kontak'];
      $status = $_POST['status'];



      mysqli_query($koneksi,"INSERT INTO reserveasi(kode_res,id_slot,nomor_slot,tnkb,nama,kontak) 
                   VALUES ('$kode_res','$id_slot','$nomor_slot','$tnkb','$nama','$kontak')");

      mysqli_query($koneksi,"update tbl_slot set nomor_slot='$nomor_slot', 
                   status='$status' where id_slot='$id_slot'");

      //header("location:index.php");
        
?>

      <table align="center">
    
        <tr align="center">
          <td colspan="3">
            <label for="disabledSelect">
              <?php             

                  $kode_res = stripslashes($_POST['kode_res']);
                  $isi_teks = $kode_res;
                  $namafile = $kode_res.".png";
                  $quality = 'H'; 
                  $ukuran = 5; 
                  $padding = 0; 
                  QRCode::png($isi_teks,$tempdir.$namafile,$quality,$ukuran,$padding);
                  echo "<img src='temp/$namafile' width='100px'><br><br>";
                  echo "<center><b>$kode_res</b></center><br>";
              ?>
            </label>
          </td>
        </tr>
      
        <tr>
          <td>Nomor Slot</td>
          <td></td>
          <td>  
          <label for="disabledSelect"> : <?php echo "$nomor_slot"; ?></label>
          </td>
        </tr>

        <tr>  
          <td>Nama</td>
          <td></td>
          <td><label for="disabledSelect"> : <?php echo "$nama"; ?></label></td>
        </tr>  

        <tr>  
          <td>Nomor Kendaraan</td>
          <td></td>
          <td><label for="disabledSelect"> : <?php echo "$tnkb"; ?></label></td>
        </tr>
        
        <tr>
          <td>Kontak</td>
          <td></td>
          <td><label for="disabledSelect"> : <?php echo "$kontak"; ?></label></td>
        </tr>

        <tr><td colspan="3"></td></tr>

        <tr align="center">
          <td colspan="3">
            <a href="index.php">
            <button class="btn btn-default btn-lg">HOME
            </button></a>
          </td>
        </tr>
      
      </table>
      
<?php
  }
 ?>

 <script>
   window.print();
 </script>