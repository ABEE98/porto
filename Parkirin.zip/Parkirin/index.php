<?php 
 include ("head.php");
 ?>

 <meta http-equiv="refresh" content="10" />
      <div id="page-wrapper" align="center">
        <div class="row">
          <div class="col-lg-15">
            <div class="alert alert-success alert-dismissable" align="center">
            Silahkan pilih slot pada area parkir untuk melakukan reservasi  
            </div>
          </div>
        </div>
        <!-- /.row -->
        <div class="row">
          <div class="col-lg-15">
            <div class="panel panel-success">
              <div class="panel-body">
                <div id="morris-chart-area">
                  <div class="row">
                    <!-- Info -->
                    <div class="col-lg-5">
                      <div class="panel panel-danger">
                        <div class="panel-heading">
                          <h3 class="panel-title" align="center">Keterangan</h3>
                        </div>
                        <div class="panel-body">
                            <?php include ("keterangan.php"); ?>
                      </div>
                    </div>
                    <!-- Area Reservasi -->
                    <div class="col-lg-7">
                      <div class="panel panel-success">
                        <div class="panel-heading">
                          <h3 class="panel-title" align="center">Area Parkir</h3>
                        </div>
                        <div class="panel-body">
                          <div class="list-group">
                            <?php include ("parkir_area.php"); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
<?php 
 include ("foot.php");
 ?>
